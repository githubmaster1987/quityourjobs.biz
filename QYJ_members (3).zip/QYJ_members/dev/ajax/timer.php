<?php date_default_timezone_set("UTC");  echo date("D, F j, Y, g:i a", time()); ?>
